<?php
// Heading
$_['heading_title_fail'] = '您的付款失敗！';

// Text
$_['text_customer_fail'] = '<p>請檢視上方的錯誤資訊，重新操作即可，如有其他問題可以 <a href="%s">與我們聯繫</a>。</p><p>感謝您的訂購！</p>';
$_['text_guest_fail']    = '<p>請檢視上方的錯誤資訊，重新操作即可，如有其他問題可以 <a href="%s">與我們聯繫</a>。</p><p>感謝您的訂購！</p>';
?>