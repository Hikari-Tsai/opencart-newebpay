<?php
// Heading
$_['heading_title_getcode']        = '專屬付款方式';
$_['heading_subtitle_getcode']		='以下為您的繳費資訊，再請您於到期日前完成付款，逾期本訂單將自動取消';
// Text
$_['text_basket']          = '購物車';
$_['text_checkout']        = '結帳';
$_['text_getcode']         = '取號';
$_['button_home']			='回首頁';
$_['button_print']			='列印條碼繳費單';


