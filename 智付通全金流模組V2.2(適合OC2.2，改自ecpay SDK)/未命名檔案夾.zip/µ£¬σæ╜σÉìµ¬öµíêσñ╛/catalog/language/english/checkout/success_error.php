<?php
// Heading
$_['heading_title_fail'] = 'Your Order Has Not Been Processed!';

// Text
$_['text_customer_fail'] = '<p>Your order has not been processed!</p><p>Please direct any questions you have to the <a href="%s">store owner</a>.</p><p>Thanks for shopping with us online!</p>';
$_['text_guest_fail']    = '<p>Your order has not been processed!</p><p>Please direct any questions you have to the <a href="%s">store owner</a>.</p><p>Thanks for shopping with us online!</p>';
?>